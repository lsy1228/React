const img = [
    {
        id : 1,
        image : 'images/kitsch.jpg',
        title : 'Kitsch',
        artist : 'IVE'
    },
    {
        id : 2,
        image : 'images/setmefree.jpg',
        title : 'SET ME FREE',
        artist : 'TWICE'
    },
    {
        id : 3,
        image : 'images/iam.jpg',
        title : 'I AM',
        artist : 'IVE'
    },
    {
        id : 4,
        image : 'images/iDontThink.jpg',
        title : "I Don't Think That I Like Her",
        artist : 'Charlie Puth'
    }
]

export default img;