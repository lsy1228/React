import React from "react";

const Home = () => {

    return (
        <>
            <p>홈입니다</p>
        </>
    );
}

export default Home;